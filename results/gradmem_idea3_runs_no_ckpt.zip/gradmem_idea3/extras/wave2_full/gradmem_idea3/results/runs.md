### 2026-10-14 10:08 · E3r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E3r again at inner_lr 0.1, the K=2 lr of the combined runs (sweep, section E)

### 2026-10-14 10:08 · E8r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E8r again at inner_lr 0.1 (K=3 best at 0.1 in the sweep)

### 2026-10-14 10:08 · E3r_a0.1_gm_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:08 · E8r_a0.1_gm_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:08 · E4_rmt_x2_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E4. RMT x2 (two forward passes) started from E1 (16 pairs)

### 2026-10-14 10:08 · E5_rmt_x3_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E5. RMT x3 (three forward passes) started from E1 (16 pairs)

### 2026-10-14 10:09 · E5_rmt_x3_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:09 · E4_rmt_x2_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:19 · E8r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E8r again at inner_lr 0.1 (K=3 best at 0.1 in the sweep)

### 2026-10-14 10:19 · E3r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E3r again at inner_lr 0.1, the K=2 lr of the combined runs (sweep, section E)

### 2026-10-14 12:24 · E3r_a0.1_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9985, 99% reached at step 23500.
- 124 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 13:09 · E8r_a0.1_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9990, 99% reached at step 22500.
- 169 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 13:30 · E5_rmt_x3_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E5. RMT x3 (three forward passes) started from E1 (16 pairs)

### 2026-10-14 13:30 · E4_rmt_x2_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E4. RMT x2 (two forward passes) started from E1 (16 pairs)

### 2026-10-14 15:00 · E4_rmt_x2_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.3694, 99% not reached.
- 89 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 15:16 · E5_rmt_x3_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.3699, 99% not reached.
- 106 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 17:48 · E3w_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. E3 again with the shared warmup 1000 and the 3-in-a-row stop (fairness fix 4)

### 2026-10-14 17:48 · E2w_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. E2 again with the shared warmup 1000 and the 3-in-a-row stop (fairness fix 4)

### 2026-10-14 19:07 · E2w_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9732, 99% not reached.
- 79 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 19:42 · E3w_gm_L4_p16_1M_s1 · finished
- Step 54000, best accuracy 0.9995, 99% reached at step 7500.
- 127 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

