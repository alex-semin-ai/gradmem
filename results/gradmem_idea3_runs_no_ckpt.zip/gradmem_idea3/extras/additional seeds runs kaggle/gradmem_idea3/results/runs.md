### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-19 12:47 · GMs_p32_K4_a0.1_s2 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 32 pairs, K = 4, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 e863796.
- Why. Final seeds. GradMem K=4 from scratch, 32 pairs, lr 0.1, seed 144

### 2026-10-19 12:47 · GMs_p32_K4_a0.1_s3 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 32 pairs, K = 4, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 e863796.
- Why. Final seeds. GradMem K=4 from scratch, 32 pairs, lr 0.1, seed 145

### 2026-10-19 13:53 · GMs_p32_K4_a0.1_s2 · finished
- Step 9000, best accuracy 0.9999, 99% reached at step 5500.
- 433 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-19 13:53 · GMs_p16_K3_a0.1_s2 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 e863796.
- Why. Final seeds. GradMem K=3 from scratch, 16 pairs, lr 0.1, seed 144

### 2026-10-19 14:09 · GMs_p32_K4_a0.1_s3 · finished
- Step 11000, best accuracy 0.9998, 99% reached at step 5500.
- 440 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-19 14:09 · GMs_p16_K3_a0.1_s3 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 e863796.
- Why. Final seeds. GradMem K=3 from scratch, 16 pairs, lr 0.1, seed 145

### 2026-10-19 14:24 · GMs_p16_K3_a0.1_s2 · finished
- Step 9500, best accuracy 0.9994, 99% reached at step 4500.
- 189 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-19 14:38 · GMs_p16_K3_a0.1_s3 · finished
- Step 9000, best accuracy 0.9998, 99% reached at step 6000.
- 190 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

