### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 18:02 · P3_l5_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 lr tuning. Scaled start 5, K=1, lr 0.1, 10k

### 2026-10-14 18:02 · P3_l5_K1_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 lr tuning. Scaled start 5, K=1, lr 0.2, 10k

### 2026-10-14 18:20 · P3_l5_K1_a0.1_s1 · finished
- Step 10000, best accuracy 0.9680, 99% not reached.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 18:20 · P3_l5_K1_a0.2_s1 · finished
- Step 10000, best accuracy 0.9608, 99% not reached.
- 104 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 18:20 · P3_l5_K1_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 lr tuning. Scaled start 5, K=1, lr 0.4, 10k

### 2026-10-14 18:20 · P3_l5_K2_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 lr tuning. Scaled start 5, K=2, lr 0.2, 10k

### 2026-10-14 18:38 · P3_l5_K1_a0.4_s1 · finished
- Step 10000, best accuracy 0.0543, 99% not reached.
- 102 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 18:38 · P3_l5_K2_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 lr tuning. Scaled start 5, K=2, lr 0.4, 10k

### 2026-10-14 18:48 · P3_l5_K2_a0.2_s1 · finished
- Step 10000, best accuracy 0.9991, 99% reached at step 4500.
- 162 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 18:48 · P3_norm0.3_K1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 backup. Raw start, normalized step 0.3, K=1, 10k

### 2026-10-14 19:05 · P3_l5_K2_a0.4_s1 · finished
- Step 10000, best accuracy 0.9994, 99% reached at step 3000.
- 159 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 19:05 · P3_norm0.5_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.5, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 backup. Raw start, normalized step 0.5, K=2, 10k

### 2026-10-14 19:05 · P3_norm0.3_K1_s1 · finished
- Step 10000, best accuracy 0.9591, 99% not reached.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 19:31 · P3_norm0.5_K2_s1 · finished
- Step 10000, best accuracy 0.9984, 99% reached at step 5500.
- 153 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

