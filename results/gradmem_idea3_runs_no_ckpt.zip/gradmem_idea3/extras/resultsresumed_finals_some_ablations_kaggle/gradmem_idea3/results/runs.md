### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 20:28 · F_l5_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=1, lr 0.1, seed 143, 60k

### 2026-10-14 20:28 · F_l5_K1_a0.1_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=1, lr 0.1, seed 144, 60k

### 2026-10-14 22:12 · F_l5_K1_a0.1_s2 · finished
- Step 60000, best accuracy 0.9951, 99% reached at step 31500.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 22:12 · F_l5_K1_a0.1_s1 · finished
- Step 60000, best accuracy 0.9957, 99% reached at step 27500.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 22:12 · F_l5_K2_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=2, lr 0.4, seed 143, 60k

### 2026-10-14 22:12 · F_l5_K1_a0.1_s3 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=1, lr 0.1, seed 145, 60k

### 2026-10-14 22:43 · F_l5_K2_a0.4_s1 · finished
- Step 11500, best accuracy 0.9994, 99% reached at step 3000.
- 159 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 22:43 · F_l5_K2_a0.4_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=2, lr 0.4, seed 144, 60k

### 2026-10-14 23:21 · F_l5_K2_a0.4_s2 · finished
- Step 14000, best accuracy 0.9996, 99% reached at step 3000.
- 160 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 23:21 · F_l5_K2_a0.4_s3 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 2 final. Scaled start 5, K=2, lr 0.4, seed 145, 60k

### 2026-10-14 23:56 · F_l5_K1_a0.1_s3 · finished
- Step 60000, best accuracy 0.9960, 99% reached at step 26500.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 23:57 · F_l5_K2_a0.4_s3 · finished
- Step 13500, best accuracy 0.9998, 99% reached at step 3000.
- 160 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 05:31 · F_l5_K1_a0.1_s1 · launch
- Resumed from checkpoint-57500. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3. Combined K=1 continued to 120k, seed 143

### 2026-10-15 05:31 · F_l5_K1_a0.1_s2 · launch
- Resumed from checkpoint-57500. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 3. Combined K=1 continued to 120k, seed 144

### 2026-10-15 07:22 · F_l5_K1_a0.1_s1 · finished
- Step 120000, best accuracy 0.9977, 99% reached at step 27500.
- 105 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 07:22 · F_l5_K1_a0.1_s3 · launch
- Resumed from checkpoint-60000. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 3. Combined K=1 continued to 120k, seed 145

### 2026-10-15 07:22 · F_l5_K1_a0.1_s2 · finished
- Step 120000, best accuracy 0.9977, 99% reached at step 31500.
- 106 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 07:23 · A_rec_l5_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3 ablation E6rec. Combined K=1, encoder reconstruction loss

### 2026-10-15 09:05 · F_l5_K1_a0.1_s3 · finished
- Step 120000, best accuracy 0.9985, 99% reached at step 26500.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 09:05 · A_C1_l5_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3 ablation C1. Combined K=1, frozen encoder

### 2026-10-15 09:31 · A_rec_l5_K1_a0.1_s1 · finished
- Step 60000, best accuracy 0.9920, 99% reached at step 47500.
- 128 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 09:31 · A_proj_l5_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3 ablation E6p. Combined K=1, projection on the scaled start

### 2026-10-15 10:39 · A_C1_l5_K1_a0.1_s1 · finished
- Step 60000, best accuracy 0.9823, 99% not reached.
- 93 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 11:16 · A_proj_l5_K1_a0.1_s1 · finished
- Step 60000, best accuracy 0.9969, 99% reached at step 22500.
- 104 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

