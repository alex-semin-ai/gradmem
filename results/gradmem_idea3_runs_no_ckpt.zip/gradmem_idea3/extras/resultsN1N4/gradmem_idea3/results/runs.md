### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:16 · P2_n1_norm0.1_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N1b. Raw start, normalized step (relative step 0.1), K=2, 10k

### 2026-10-14 10:16 · P2_n1_memsq_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N1. Raw start, step x (||M||/||mem||)^2, K=2, 10k

### 2026-10-14 10:43 · P2_n1_memsq_K2_s1 · finished
- Step 10000, best accuracy 0.9815, 99% not reached.
- 160 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:43 · P2_n1_norm0.3_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N1b. Raw start, normalized step (relative step 0.3), K=2, 10k

### 2026-10-14 10:44 · P2_n1_norm0.1_K2_s1 · finished
- Step 10000, best accuracy 0.9925, 99% reached at step 8500.
- 164 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:44 · P2_n3_random_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N3, C4. Random direction of length 1.6 per example, K=2, 10k

### 2026-10-14 11:10 · P2_n3_random_K2_s1 · finished
- Step 10000, best accuracy 0.6859, 99% not reached.
- 154 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 11:10 · P2_n3_scaled_K2_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. N3. P1_scaled_K2 again with seed 144, 10k

### 2026-10-14 11:10 · P2_n1_norm0.3_K2_s1 · finished
- Step 10000, best accuracy 0.9982, 99% reached at step 5000.
- 162 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 11:11 · P2_n2_l5_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N2. Scaled start, length 5, K=2, 10k

### 2026-10-14 11:38 · P2_n2_l5_K2_s1 · finished
- Step 10000, best accuracy 0.9993, 99% reached at step 4500.
- 160 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 11:38 · P2_n2_l10_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N2. Scaled start, length 10, K=2, 10k

### 2026-10-14 11:38 · P2_n3_scaled_K2_s2 · finished
- Step 10000, best accuracy 0.9936, 99% reached at step 8500.
- 166 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 11:38 · P2_n2_l20_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N2. Scaled start, length 20, K=2, 10k

### 2026-10-14 12:05 · P2_n2_l10_K2_s1 · finished
- Step 10000, best accuracy 0.9980, 99% reached at step 6500.
- 164 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 12:06 · P2_n4_scaled_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N4. Scaled start 1.6, K=1, inner lr 0.1, 10k

### 2026-10-14 12:06 · P2_n2_l20_K2_s1 · finished
- Step 10000, best accuracy 0.9838, 99% not reached.
- 168 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 12:07 · P2_n4_projsc_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N4. Scaled start 1.6 + projection, K=1, inner lr 0.1, 10k

### 2026-10-14 12:25 · P2_n4_scaled_K1_a0.1_s1 · finished
- Step 10000, best accuracy 0.9203, 99% not reached.
- 112 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 12:26 · P2_n4_projsc_K1_a0.1_s1 · finished
- Step 10000, best accuracy 0.8869, 99% not reached.
- 113 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

