### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 09:03 · S_gm_K3_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=3 from E1, inner_lr 0.1, 10k steps

### 2026-10-13 09:03 · S_gm_K3_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=3 from E1, inner_lr 0.2, 10k steps

### 2026-10-13 09:35 · S_gm_K3_a0.2_s1 · finished
- Step 10000, best accuracy 0.1566, 99% not reached.
- 193 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 09:36 · S_comb_K2_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=2 from E1, inner_lr 0.1, 10k steps

### 2026-10-13 09:36 · S_gm_K3_a0.1_s1 · finished
- Step 10000, best accuracy 0.9822, 99% not reached.
- 197 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 09:37 · S_comb_K2_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=2 from E1, inner_lr 0.2, 10k steps

### 2026-10-13 10:02 · S_comb_K2_a0.1_s1 · finished
- Step 10000, best accuracy 0.3691, 99% not reached.
- 154 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:02 · S_comb_K2_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=2 from E1, inner_lr 0.4, 10k steps

### 2026-10-13 10:03 · S_comb_K2_a0.2_s1 · finished
- Step 10000, best accuracy 0.3739, 99% not reached.
- 159 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:04 · S_gm_K2_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=2 from E1, inner_lr 0.1, 10k steps

### 2026-10-13 10:27 · S_gm_K2_a0.1_s1 · finished
- Step 10000, best accuracy 0.9917, 99% reached at step 9000.
- 141 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:28 · S_gm_K2_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=2 from E1, inner_lr 0.2, 10k steps

### 2026-10-13 10:28 · S_comb_K2_a0.4_s1 · finished
- Step 10000, best accuracy 0.3752, 99% not reached.
- 154 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:28 · S_comb_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=1 from E1, inner_lr 0.1, 10k steps

### 2026-10-13 10:45 · S_comb_K1_a0.1_s1 · finished
- Step 10000, best accuracy 0.3682, 99% not reached.
- 101 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:46 · S_comb_K1_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=1 from E1, inner_lr 0.2, 10k steps

### 2026-10-13 10:51 · S_gm_K2_a0.2_s1 · finished
- Step 10000, best accuracy 0.9883, 99% not reached.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 10:52 · S_comb_K1_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). combined K=1 from E1, inner_lr 0.4, 10k steps

### 2026-10-13 11:03 · S_comb_K1_a0.2_s1 · finished
- Step 10000, best accuracy 0.3689, 99% not reached.
- 102 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 11:03 · S_gm_K1_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=1 from E1, inner_lr 0.1, 10k steps

### 2026-10-13 11:09 · S_comb_K1_a0.4_s1 · finished
- Step 10000, best accuracy 0.3715, 99% not reached.
- 103 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 11:09 · S_gm_K1_a0.2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.2, 4 layers, hidden 128, seed 143.
- Code my-idea3 b486ac9.
- Why. Inner lr sweep (D7). gradmem K=1 from E1, inner_lr 0.2, 10k steps

### 2026-10-13 11:17 · S_gm_K1_a0.1_s1 · finished
- Step 10000, best accuracy 0.7792, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 11:23 · S_gm_K1_a0.2_s1 · finished
- Step 10000, best accuracy 0.6631, 99% not reached.
- 82 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

