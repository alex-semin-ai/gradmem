### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 17:45 · E2_gm_L4_p16_1M_s1 · conclusion
- K=1 from scratch hit the 60k cap at 95.1% token accuracy and 44.8% exact match, still rising after a plateau near 87% from 15k to 40k.

### 2026-10-12 17:45 · E3_gm_L4_p16_1M_s1 · conclusion
- K=2 from scratch reached 99% token accuracy at 10.5k and the stop rule (99.2% exact match) at 28.5k. Write steps matter at 16 pairs.

### 2026-10-12 17:45 · E2r_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2r. GradMem K=1 started from E1 (16 pairs), no encoder

### 2026-10-12 17:45 · E3r_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3r. GradMem K=2 started from E1 (16 pairs), no encoder

### 2026-10-12 19:07 · E2r_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9817, 99% not reached.
- 81 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 19:07 · E8r_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E8r. GradMem K=3 started from E1 (16 pairs), no encoder

### 2026-10-12 20:04 · E3r_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9987, 99% reached at step 11500.
- 138 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 22:19 · E8r_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9925, 99% reached at step 47500.
- 191 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

