### 2026-10-14 10:08 · E3r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E3r again at inner_lr 0.1, the K=2 lr of the combined runs (sweep, section E)

### 2026-10-14 10:08 · E8r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E8r again at inner_lr 0.1 (K=3 best at 0.1 in the sweep)

### 2026-10-14 10:08 · E3r_a0.1_gm_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:08 · E8r_a0.1_gm_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:08 · E4_rmt_x2_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E4. RMT x2 (two forward passes) started from E1 (16 pairs)

### 2026-10-14 10:08 · E5_rmt_x3_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E5. RMT x3 (three forward passes) started from E1 (16 pairs)

### 2026-10-14 10:09 · E5_rmt_x3_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:09 · E4_rmt_x2_L4_p16_1M_s1 · failed (CalledProcessError)
- Step 0, no eval yet, 99% not reached.
- no steps in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 10:19 · E8r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E8r again at inner_lr 0.1 (K=3 best at 0.1 in the sweep)

### 2026-10-14 10:19 · E3r_a0.1_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N6. E3r again at inner_lr 0.1, the K=2 lr of the combined runs (sweep, section E)

### 2026-10-14 12:24 · E3r_a0.1_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9985, 99% reached at step 23500.
- 124 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 13:09 · E8r_a0.1_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9990, 99% reached at step 22500.
- 169 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 13:30 · E5_rmt_x3_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E5. RMT x3 (three forward passes) started from E1 (16 pairs)

### 2026-10-14 13:30 · E4_rmt_x2_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. N8. E4. RMT x2 (two forward passes) started from E1 (16 pairs)

### 2026-10-14 15:00 · E4_rmt_x2_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.3694, 99% not reached.
- 89 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 15:16 · E5_rmt_x3_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.3699, 99% not reached.
- 106 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 17:48 · E3w_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. E3 again with the shared warmup 1000 and the 3-in-a-row stop (fairness fix 4)

### 2026-10-14 17:48 · E2w_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. E2 again with the shared warmup 1000 and the 3-in-a-row stop (fairness fix 4)

### 2026-10-14 19:07 · E2w_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9732, 99% not reached.
- 79 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 19:42 · E3w_gm_L4_p16_1M_s1 · finished
- Step 54000, best accuracy 0.9995, 99% reached at step 7500.
- 127 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 20:26 · E8r_a0.1_gm_L4_p16_1M_s3 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=3 from E1, lr 0.1, seed 145

### 2026-10-14 20:26 · E8r_a0.1_gm_L4_p16_1M_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=3 from E1, lr 0.1, seed 144

### 2026-10-14 22:25 · E8r_a0.1_gm_L4_p16_1M_s3 · finished
- Step 39500, best accuracy 0.9996, 99% reached at step 18500.
- 179 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 22:25 · E3r_a0.1_gm_L4_p16_1M_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=2 from E1, lr 0.1, seed 144

### 2026-10-14 23:26 · E8r_a0.1_gm_L4_p16_1M_s2 · finished
- Step 60000, best accuracy 0.9992, 99% reached at step 17500.
- 180 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-14 23:26 · E3r_a0.1_gm_L4_p16_1M_s3 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=2 from E1, lr 0.1, seed 145

### 2026-10-15 00:31 · E3r_a0.1_gm_L4_p16_1M_s2 · finished
- Step 60000, best accuracy 0.9983, 99% reached at step 15000.
- 126 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 00:31 · E2r_gm_L4_p16_1M_s2 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=1 from E1, lr 0.4, seed 144

### 2026-10-15 01:34 · E3r_a0.1_gm_L4_p16_1M_s3 · finished
- Step 60000, best accuracy 0.9982, 99% reached at step 21500.
- 128 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 01:34 · E2r_gm_L4_p16_1M_s3 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 2 baseline seed. GradMem K=1 from E1, lr 0.4, seed 145

### 2026-10-15 01:49 · E2r_gm_L4_p16_1M_s2 · finished
- Step 60000, best accuracy 0.9238, 99% not reached.
- 78 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 02:52 · E2r_gm_L4_p16_1M_s3 · finished
- Step 60000, best accuracy 0.9632, 99% not reached.
- 77 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 05:27 · E3r_a0.1_gm_L4_p16_1M_s2 · launch
- Resumed from checkpoint-60000. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 144.
- Code my-idea3 4f49604.
- Why. Wave 3. E3r continued to 120k (same budget as combined K=1), seed 144

### 2026-10-15 05:27 · E3r_a0.1_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-56000. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3. E3r continued to 120k (same budget as combined K=1), seed 143

### 2026-10-15 07:35 · E3r_a0.1_gm_L4_p16_1M_s2 · finished
- Step 120000, best accuracy 0.9989, 99% reached at step 15000.
- 127 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 07:35 · E3r_a0.1_gm_L4_p16_1M_s3 · launch
- Resumed from checkpoint-60000. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 145.
- Code my-idea3 4f49604.
- Why. Wave 3. E3r continued to 120k (same budget as combined K=1), seed 145

### 2026-10-15 07:45 · E3r_a0.1_gm_L4_p16_1M_s1 · finished
- Step 120000, best accuracy 0.9995, 99% reached at step 23500.
- 129 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 07:45 · A_rec_l5_K2_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3 ablation E7rec. Combined K=2, scaled start 5, lr 0.4, encoder reconstruction loss

### 2026-10-15 08:32 · A_rec_l5_K2_a0.4_s1 · finished
- Step 16000, best accuracy 0.9996, 99% reached at step 5000.
- 173 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 08:32 · A_C1_l5_K2_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3 ablation C1. Combined K=2, scaled start 5, lr 0.4, frozen encoder

### 2026-10-15 09:28 · E3r_a0.1_gm_L4_p16_1M_s3 · finished
- Step 115000, best accuracy 0.9996, 99% reached at step 21500.
- 124 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 09:29 · E2rw_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. Wave 3. E2r seed 143 again under the current rules (fairness)

### 2026-10-15 10:24 · A_C1_l5_K2_a0.4_s1 · finished
- Step 48000, best accuracy 0.9995, 99% reached at step 5000.
- 140 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 10:47 · E2rw_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9026, 99% not reached.
- 79 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 15:01 · E1_rmt_L4_p32_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 32 pairs, K = 1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage A. RMT x1 parent at 32 pairs, reconstruction loss, 100k steps

### 2026-10-15 17:01 · E1_rmt_L4_p32_1M_s1 · finished
- Step 100000, best accuracy 0.0504, 99% not reached.
- 72 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 19:00 · GM_p32_K4_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 4, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. GradMem K=4 from E1 p32, lr 0.1

### 2026-10-15 19:00 · CB_p32_K3_l5_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. RMT encoder + GradMem K=3, scaled start 5, lr 0.1

### 2026-10-15 23:33 · CB_p32_K3_l5_a0.1_s1 · finished
- Step 58000, best accuracy 0.9997, 99% reached at step 5000.
- 283 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-15 23:33 · GM_p32_K3_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 3, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. GradMem K=3 from E1 p32, lr 0.1

### 2026-10-16 00:29 · GM_p32_K4_a0.1_s1 · finished
- Step 60000, best accuracy 0.9620, 99% not reached.
- 329 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-16 00:29 · CB_p32_K2_l5_a0.4_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. RMT encoder + GradMem K=2, scaled start 5, lr 0.4

### 2026-10-16 03:45 · GM_p32_K3_a0.1_s1 · finished
- Step 60000, best accuracy 0.9221, 99% not reached.
- 252 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-16 03:46 · GM_p32_K2_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. GradMem K=2 from E1 p32, lr 0.1

### 2026-10-16 03:57 · CB_p32_K2_l5_a0.4_s1 · finished
- Step 60000, best accuracy 0.9982, 99% reached at step 18500.
- 207 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-16 03:57 · CB_p32_K1_l5_a0.1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p32_1M_s1/checkpoint-99500.
- Settings. 32 pairs, K = 1, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 4f49604.
- Why. 32-pair test, stage B. RMT encoder + GradMem K=1, scaled start 5, lr 0.1

### 2026-10-16 06:11 · CB_p32_K1_l5_a0.1_s1 · finished
- Step 60000, best accuracy 0.9005, 99% not reached.
- 134 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-16 06:44 · GM_p32_K2_a0.1_s1 · finished
- Step 60000, best accuracy 0.6201, 99% not reached.
- 178 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

