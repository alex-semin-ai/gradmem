### 2026-10-12 13:58 · E3_gm_L4_p16_1M_s1 · launch
- New run from step 0. Initial weights from scratch.
- Settings. 16 pairs, K = 2, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E3. GradMem K=2 reference from scratch

### 2026-10-12 13:58 · E2_gm_L4_p16_1M_s1 · launch
- Resumed from checkpoint-9500. Initial weights from scratch.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 2116c96.
- Why. E2. GradMem K=1 reference from scratch

### 2026-10-12 15:06 · E3_gm_L4_p16_1M_s1 · finished
- Step 28500, best accuracy 0.9995, 99% reached at step 10500.
- 142 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-12 15:10 · E2_gm_L4_p16_1M_s1 · finished
- Step 60000, best accuracy 0.9507, 99% not reached.
- 84 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 19:59 · P1_mixed_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=2, start mixed, 10k steps

### 2026-10-13 19:59 · P1_scaled_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=2, start scaled, 10k steps

### 2026-10-13 20:26 · P1_scaled_K2_s1 · finished
- Step 10000, best accuracy 0.9975, 99% reached at step 6000.
- 160 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 20:27 · P1_projsc_K2_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 2, inner_lr 0.1, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=2, start projsc, 10k steps

### 2026-10-13 20:27 · P1_mixed_K2_s1 · finished
- Step 10000, best accuracy 0.9832, 99% not reached.
- 162 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 20:27 · P1_scaled_K1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=1, start scaled, 10k steps

### 2026-10-13 20:45 · P1_scaled_K1_s1 · finished
- Step 10000, best accuracy 0.0540, 99% not reached.
- 104 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 20:45 · P1_mixed_K1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=1, start mixed, 10k steps

### 2026-10-13 20:54 · P1_projsc_K2_s1 · finished
- Step 10000, best accuracy 0.9939, 99% reached at step 7500.
- 162 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 20:54 · P1_projsc_K1_s1 · launch
- New run from step 0. Initial weights from E1_rmt_L4_p16_1M_s1/checkpoint-100000.
- Settings. 16 pairs, K = 1, inner_lr 0.4, 4 layers, hidden 128, seed 143.
- Code my-idea3 237cda3.
- Why. Stage 1 pilot. Combined K=1, start projsc, 10k steps

### 2026-10-13 21:03 · P1_mixed_K1_s1 · finished
- Step 10000, best accuracy 0.1139, 99% not reached.
- 104 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

### 2026-10-13 21:11 · P1_projsc_K1_s1 · finished
- Step 10000, best accuracy 0.0556, 99% not reached.
- 101 ms per step in this session.
- Conclusion. Add it with the conclusion cell.

